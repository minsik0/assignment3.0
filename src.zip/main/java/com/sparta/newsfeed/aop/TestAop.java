package com.sparta.newsfeed.aop;

import com.sparta.newsfeed.entity.Users.User;
import com.sparta.newsfeed.repository.UserRepository;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;

import org.springframework.stereotype.Component;
// Logback을 이용한 로깅을 위해 Slf4j 어노테이션 사용
@Slf4j(topic = "testAop")
// AOP를 정의하는 클래스임을 나타냄
@Aspect
// Spring의 컴포넌트로 등록하여 빈으로 사용 가능하게 함
@Component
// 생성자를 통한 의존성 주입을 자동으로 처리해주는 Lombok 어노테이션
@RequiredArgsConstructor
public class TestAop {
    // UserRepository를 통해 데이터베이스 작업을 수행하기 위한 의존성 주입
    private final UserRepository userRepository;

    // BoardController의 모든 메서드를 대상으로 하는 포인트컷 정의
    @Pointcut("execution(* com.sparta.newsfeed.controller.BoardController.*(..))")
    private void board(){}

    // CommentController의 모든 메서드를 대상으로 하는 포인트컷 정의
    @Pointcut("execution(* com.sparta.newsfeed.controller.CommentController.*(..))")
    private void comment(){}

    // UserController의 모든 메서드를 대상으로 하는 포인트컷 정의
    @Pointcut("execution(* com.sparta.newsfeed.controller.UserController.*(..))")
    private void User(){}

    // 모든 컨트롤러 패키지 내의 메서드를 대상으로 하는 어드바이스 정의
    @Around("execution(* com.sparta.newsfeed.controller..*(..))")
    public Object logRequestAndMeasureTime(ProceedingJoinPoint joinPoint) throws Throwable {

        // 메서드 실행 시작 시간 기록
        long startTime = System.currentTimeMillis();

        HttpServletRequest request = null;

        // 메서드 인자들 중 HttpServletRequest를 찾음
        for (Object arg : joinPoint.getArgs()) {
            if (arg instanceof HttpServletRequest) {
                request = (HttpServletRequest) arg;
                break;
            }
        }

        try {
            // 요청 세부 정보 로깅
            if (request != null) {

                // 요청 URL과 HTTP 메서드를 로그로 출력
                log.info("요청 URL: {}, HTTP 메서드: {}", request.getRequestURL(), request.getMethod());
            }

            // 메서드 실행
            Object output = joinPoint.proceed();
            return output;
        } finally {
            // 실행 시간 측정
            long endTime = System.currentTimeMillis();

            // 실행 시간 계산
            long runtime = endTime - startTime;

            // User 엔티티 생성 및 실행 시간 설정
            User user = new User(runtime);

            // 실행 시간을 데이터베이스에 저장
            userRepository.save(user);

            // 실행 시간 로그 출력
            log.info("[API 사용 시간] 총 시간: {} ms", runtime);
        }
    }
}

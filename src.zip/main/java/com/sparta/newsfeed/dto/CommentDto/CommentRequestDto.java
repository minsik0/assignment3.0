package com.sparta.newsfeed.dto.CommentDto;


import lombok.Getter;

@Getter
public class CommentRequestDto {

    private Long id;
    private Long user_id;
    private String contents;

    public CommentRequestDto(String testComment) {
        this.contents = contents;
    }


    public String getContents() {
        return contents;
    }

    public void setContent(String s) {
        this.contents = contents;
    }
}

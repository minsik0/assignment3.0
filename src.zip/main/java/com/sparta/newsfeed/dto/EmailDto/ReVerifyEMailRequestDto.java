//package com.sparta.newsfeed.dto.EmailDto;
//
//import lombok.Getter;
//
//@Getter
//public class ReVerifyEMailRequestDto {
//    private String email;
//    private String password;
//}
package com.sparta.newsfeed.dto.FollowDto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class FollowStatusRequestDto {
    private Long userId;
}
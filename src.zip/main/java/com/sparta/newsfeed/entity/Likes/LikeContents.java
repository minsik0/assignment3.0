package com.sparta.newsfeed.entity.Likes;

public enum LikeContents {
    BOARD,
    COMMENT
}
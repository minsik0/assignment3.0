package com.sparta.newsfeed.controller;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.BDDMockito.given;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.jsonPath;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sparta.newsfeed.dto.CommentDto.CommentRequestDto;
import com.sparta.newsfeed.service.CommentService;
import jakarta.servlet.http.HttpServletRequest;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import static org.junit.jupiter.api.Assertions.*;
/*
@WebMvcTest(CommentController.class)
public class CommentControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private CommentService commentService;

    @Autowired
    private ObjectMapper objectMapper;

    @Test
    public void testCreateComment() throws Exception {
        // Given: 테스트 조건 설정
        Long boardId = 1L;
        CommentRequestDto commentRequestDto = new CommentRequestDto();
        // 필요한 필드 설정
        String commentContent = "댓글 내용";
        commentRequestDto.setContent(commentContent);

        String expectedResponse = "댓글 생성 성공";

        given(commentService.createComment(any(HttpServletRequest.class), eq(boardId), any(CommentRequestDto.class)))
                .willReturn(expectedResponse);

        // When: 테스트 액션 실행
        mockMvc.perform(post("/" + boardId + "/comment")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(commentRequestDto)))
                // Then: 결과 검증
                .andExpect(status().isOk());
    }
}
*/

package com.sparta.newsfeed.service;

import com.sparta.newsfeed.dto.UserDto.LoginUpRequestDto;
import com.sparta.newsfeed.dto.UserDto.SignUpRequestDto;
import com.sparta.newsfeed.entity.Users.User;
import com.sparta.newsfeed.repository.UserRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@ExtendWith(SpringExtension.class)
@SpringBootTest
public class UserServiceIntegrationTest {

    @Autowired
    private SignUpService signUpService;

    @Autowired
    private UserRepository userRepository;

    @Test
    void testSignUser() {
        // given
        SignUpRequestDto requestDto = new SignUpRequestDto();
        requestDto.setUserId("testUser123");
        requestDto.setPassword("Password123!");
        requestDto.setUsername("Test User");


        // when
        String userId = signUpService.addUser(requestDto);

        // then
        User createdUser = userRepository.findByUserId(userId);
        assertNotNull(createdUser);
        assertEquals("testUser123", createdUser.getUserId());
    }

    @Test
    void testLoginUser() {
        // given
        LoginUpRequestDto loginDto = new LoginUpRequestDto();
        loginDto.setUserId("testUser123");
        loginDto.setPassword("Password123!");

        // when
        String result = signUpService.loginUser(loginDto, null);

        // then
        assertEquals("로그인이 완료되었습니다", result);
    }
/*
    @Test
    void testLogoutUser() {
        // given
        LoginUpRequestDto loginDto = new LoginUpRequestDto();
        loginDto.setUserId("testUser123");
        loginDto.setPassword("Password123!");

        // when
        String result = signUpService.logoutUser(loginDto, null);

        // then
        assertEquals("로그아웃이 완료되었습니다", result);
    }
*/
    @Test
    void testDeleteUser() {
        // given
        LoginUpRequestDto loginDto = new LoginUpRequestDto();
        loginDto.setUserId("testUser123");
        loginDto.setPassword("Password123!");

        // when
        String result = signUpService.deleteUser(loginDto, null, null);

        // then
        assertEquals("회원탈퇴가 완료되었습니다.", result);
    }


}

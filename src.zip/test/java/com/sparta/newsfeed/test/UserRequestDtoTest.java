package com.sparta.newsfeed.test;

import com.sparta.newsfeed.dto.UserDto.UserRequestDto;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class UserRequestDtoTest {

    @Test
    void testDtoCreation() {
        UserRequestDto userRequestDto = new UserRequestDto();
        userRequestDto.setUsername("Test User");
//        userRequestDto.setOneLiner("Hello!");

        assertEquals("Test User", userRequestDto.getUsername());
//        assertEquals("test@example.com", userRequestDto.getEmail());
//        assertEquals("Hello!", userRequestDto.getOneLiner());
    }
}

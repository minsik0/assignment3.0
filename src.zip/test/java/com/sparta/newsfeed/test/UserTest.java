package com.sparta.newsfeed.test;

import com.sparta.newsfeed.entity.Users.User;
import org.junit.jupiter.api.*;

import static org.junit.jupiter.api.Assertions.*;

public class UserTest {

    private User user;

    @BeforeAll
    static void beforeAll() {
        // 테스트 클래스 전체에서 처음 한 번만 실행
        System.out.println("Before all 테스트");
    }

    @AfterAll
    static void afterAll() {
        // 테스트 클래스 전체에서 마지막으로 한 번만 실행
        System.out.println("After all 테스트");
    }

    @BeforeEach
    void setUp() {
        // 각 테스트 메소드가 실행되기 전에 실행
        user = new User();
        System.out.println("Before each 테스트");
    }

    @AfterEach
    void tearDown() {
        // 각 테스트 메소드가 실행된 후에 실행
        user = null; // 필요에 따라 정리 작업 수행
        System.out.println("After each 테스트");
    }

    @Test
    void testUserCreation() {
        // given
        User user = new User();

        // when
        user.setUserId("testUser123");
        user.setPassword("password123");

        // then
        assertEquals("testUser123", user.getUserId());
        assertEquals("password123", user.getPassword());
    }

    @Test
    void testAddUseTime() {
        // given
        User user = new User();
        user.setTotalTime(0L);

        // when
        user.addUseTime(500L);

        // then
        assertEquals(500L, user.getTotalTime());
    }

    @Test
    void testAddUseTimeWithNegativeValue() {
        // given
        User user = new User();
        user.setTotalTime(0L);

        // when
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            user.addUseTime(-100L);
        });

        // then
        String expectedMessage = "사용시간이 0보다 작을 수 없습니다.";
        String actualMessage = exception.getMessage();

        assertTrue(actualMessage.contains(expectedMessage));
    }


}
